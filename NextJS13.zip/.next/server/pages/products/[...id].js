"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/products/[...id]";
exports.ids = ["pages/products/[...id]"];
exports.modules = {

/***/ "./pages/products/[...id].jsx":
/*!************************************!*\
  !*** ./pages/products/[...id].jsx ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Product)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction Product() {\n    //get id from url\n    const { id  } = useParams();\n    console.log(id);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        style: {\n            width: \"100%\",\n            height: \"50vh\"\n        },\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"img\", {\n            src: \"/Images/product.jpg\",\n            style: {\n                height: \"100%\",\n                width: \"100%\"\n            }\n        }, void 0, false, {\n            fileName: \"D:\\\\Code\\\\FiverrProjects\\\\NextJS13\\\\pages\\\\products\\\\[...id].jsx\",\n            lineNumber: 9,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"D:\\\\Code\\\\FiverrProjects\\\\NextJS13\\\\pages\\\\products\\\\[...id].jsx\",\n        lineNumber: 8,\n        columnNumber: 5\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9wcm9kdWN0cy9bLi4uaWRdLmpzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBO0FBQTBCO0FBRVgsU0FBU0MsVUFBVTtJQUNoQyxpQkFBaUI7SUFDakIsTUFBTSxFQUFFQyxHQUFFLEVBQUUsR0FBR0M7SUFDZkMsUUFBUUMsR0FBRyxDQUFDSDtJQUNaLHFCQUNFLDhEQUFDSTtRQUFJQyxPQUFPO1lBQUVDLE9BQU87WUFBUUMsUUFBUTtRQUFPO2tCQUMxQyw0RUFBQ0M7WUFDQ0MsS0FBSTtZQUNKSixPQUFPO2dCQUFFRSxRQUFRO2dCQUFRRCxPQUFPO1lBQU87Ozs7Ozs7Ozs7O0FBSS9DLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9wcm9kdWN0ZGVzaWduLy4vcGFnZXMvcHJvZHVjdHMvWy4uLmlkXS5qc3g/NThiOCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQcm9kdWN0KCkge1xyXG4gIC8vZ2V0IGlkIGZyb20gdXJsXHJcbiAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zKCk7XHJcbiAgY29uc29sZS5sb2coaWQpO1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiwgaGVpZ2h0OiBcIjUwdmhcIiB9fT5cclxuICAgICAgPGltZ1xyXG4gICAgICAgIHNyYz0nL0ltYWdlcy9wcm9kdWN0LmpwZydcclxuICAgICAgICBzdHlsZT17eyBoZWlnaHQ6IFwiMTAwJVwiLCB3aWR0aDogXCIxMDAlXCIgfX1cclxuICAgICAgLz5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl0sIm5hbWVzIjpbIlJlYWN0IiwiUHJvZHVjdCIsImlkIiwidXNlUGFyYW1zIiwiY29uc29sZSIsImxvZyIsImRpdiIsInN0eWxlIiwid2lkdGgiLCJoZWlnaHQiLCJpbWciLCJzcmMiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/products/[...id].jsx\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/products/[...id].jsx"));
module.exports = __webpack_exports__;

})();
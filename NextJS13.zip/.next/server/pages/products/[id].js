"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/products/[id]";
exports.ids = ["pages/products/[id]"];
exports.modules = {

/***/ "./pages/products/[id].jsx":
/*!*********************************!*\
  !*** ./pages/products/[id].jsx ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Product)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nconst dummycards = [\n    {\n        id: 1,\n        title: \"Card 1\",\n        description: \"This is card 1\"\n    },\n    {\n        id: 2,\n        title: \"Card 2\",\n        description: \"This is card 2\"\n    },\n    {\n        id: 3,\n        title: \"Card 3\",\n        description: \"This is card 3\"\n    },\n    {\n        id: 4,\n        title: \"Card 4\",\n        description: \"This is card 4\"\n    },\n    {\n        id: 5,\n        title: \"Card 5\",\n        description: \"This is card 5\"\n    },\n    {\n        id: 6,\n        title: \"Card 6\",\n        description: \"This is card 6\"\n    }\n];\nfunction Product() {\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    console.log(typeof router.query.id);\n    const [product, setProduct] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(dummycards.find((p)=>p.id === parseInt(router.query.id)));\n    //get id from url\n    console.log(product);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        style: {\n            width: \"100%\",\n            height: \"50vh\",\n            position: \"relative\"\n        },\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"img\", {\n                src: \"/Images/product.jpg\",\n                style: {\n                    height: \"100%\",\n                    width: \"100%\"\n                }\n            }, void 0, false, {\n                fileName: \"D:\\\\Code\\\\FiverrProjects\\\\NextJS13\\\\pages\\\\products\\\\[id].jsx\",\n                lineNumber: 45,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                style: {\n                    position: \"absolute\",\n                    top: \"20%\",\n                    left: \"10%\",\n                    fontSize: \"2rem\"\n                },\n                children: product?.title\n            }, void 0, false, {\n                fileName: \"D:\\\\Code\\\\FiverrProjects\\\\NextJS13\\\\pages\\\\products\\\\[id].jsx\",\n                lineNumber: 49,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"D:\\\\Code\\\\FiverrProjects\\\\NextJS13\\\\pages\\\\products\\\\[id].jsx\",\n        lineNumber: 44,\n        columnNumber: 5\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9wcm9kdWN0cy9baWRdLmpzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUE7QUFBd0M7QUFDQTtBQUN4QyxNQUFNRyxhQUFhO0lBQ2pCO1FBQ0VDLElBQUk7UUFDSkMsT0FBTztRQUNQQyxhQUFhO0lBQ2Y7SUFDQTtRQUNFRixJQUFJO1FBQ0pDLE9BQU87UUFDUEMsYUFBYTtJQUNmO0lBQ0E7UUFDRUYsSUFBSTtRQUNKQyxPQUFPO1FBQ1BDLGFBQWE7SUFDZjtJQUNBO1FBQ0VGLElBQUk7UUFDSkMsT0FBTztRQUNQQyxhQUFhO0lBQ2Y7SUFDQTtRQUNFRixJQUFJO1FBQ0pDLE9BQU87UUFDUEMsYUFBYTtJQUNmO0lBQ0E7UUFDRUYsSUFBSTtRQUNKQyxPQUFPO1FBQ1BDLGFBQWE7SUFDZjtDQUNEO0FBQ2MsU0FBU0MsVUFBVTtJQUNoQyxNQUFNQyxTQUFTTixzREFBU0E7SUFDeEJPLFFBQVFDLEdBQUcsQ0FBQyxPQUFPRixPQUFPRyxLQUFLLENBQUNQLEVBQUU7SUFDbEMsTUFBTSxDQUFDUSxTQUFTQyxXQUFXLEdBQUdaLCtDQUFRQSxDQUNwQ0UsV0FBV1csSUFBSSxDQUFDLENBQUNDLElBQU1BLEVBQUVYLEVBQUUsS0FBS1ksU0FBU1IsT0FBT0csS0FBSyxDQUFDUCxFQUFFO0lBRTFELGlCQUFpQjtJQUNqQkssUUFBUUMsR0FBRyxDQUFDRTtJQUNaLHFCQUNFLDhEQUFDSztRQUFJQyxPQUFPO1lBQUVDLE9BQU87WUFBUUMsUUFBUTtZQUFRQyxVQUFVO1FBQVc7OzBCQUNoRSw4REFBQ0M7Z0JBQ0NDLEtBQUk7Z0JBQ0pMLE9BQU87b0JBQUVFLFFBQVE7b0JBQVFELE9BQU87Z0JBQU87Ozs7OzswQkFFekMsOERBQUNLO2dCQUNDTixPQUFPO29CQUNMRyxVQUFVO29CQUNWSSxLQUFLO29CQUNMQyxNQUFNO29CQUNOQyxVQUFVO2dCQUNaOzBCQUVDZixTQUFTUDs7Ozs7Ozs7Ozs7O0FBSWxCLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9wcm9kdWN0ZGVzaWduLy4vcGFnZXMvcHJvZHVjdHMvW2lkXS5qc3g/ZTMxNCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcbmNvbnN0IGR1bW15Y2FyZHMgPSBbXHJcbiAge1xyXG4gICAgaWQ6IDEsXHJcbiAgICB0aXRsZTogXCJDYXJkIDFcIixcclxuICAgIGRlc2NyaXB0aW9uOiBcIlRoaXMgaXMgY2FyZCAxXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogMixcclxuICAgIHRpdGxlOiBcIkNhcmQgMlwiLFxyXG4gICAgZGVzY3JpcHRpb246IFwiVGhpcyBpcyBjYXJkIDJcIixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiAzLFxyXG4gICAgdGl0bGU6IFwiQ2FyZCAzXCIsXHJcbiAgICBkZXNjcmlwdGlvbjogXCJUaGlzIGlzIGNhcmQgM1wiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IDQsXHJcbiAgICB0aXRsZTogXCJDYXJkIDRcIixcclxuICAgIGRlc2NyaXB0aW9uOiBcIlRoaXMgaXMgY2FyZCA0XCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogNSxcclxuICAgIHRpdGxlOiBcIkNhcmQgNVwiLFxyXG4gICAgZGVzY3JpcHRpb246IFwiVGhpcyBpcyBjYXJkIDVcIixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiA2LFxyXG4gICAgdGl0bGU6IFwiQ2FyZCA2XCIsXHJcbiAgICBkZXNjcmlwdGlvbjogXCJUaGlzIGlzIGNhcmQgNlwiLFxyXG4gIH0sXHJcbl07XHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFByb2R1Y3QoKSB7XHJcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcbiAgY29uc29sZS5sb2codHlwZW9mIHJvdXRlci5xdWVyeS5pZCk7XHJcbiAgY29uc3QgW3Byb2R1Y3QsIHNldFByb2R1Y3RdID0gdXNlU3RhdGUoXHJcbiAgICBkdW1teWNhcmRzLmZpbmQoKHApID0+IHAuaWQgPT09IHBhcnNlSW50KHJvdXRlci5xdWVyeS5pZCkpXHJcbiAgKTtcclxuICAvL2dldCBpZCBmcm9tIHVybFxyXG4gIGNvbnNvbGUubG9nKHByb2R1Y3QpO1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiwgaGVpZ2h0OiBcIjUwdmhcIiwgcG9zaXRpb246IFwicmVsYXRpdmVcIiB9fT5cclxuICAgICAgPGltZ1xyXG4gICAgICAgIHNyYz0nL0ltYWdlcy9wcm9kdWN0LmpwZydcclxuICAgICAgICBzdHlsZT17eyBoZWlnaHQ6IFwiMTAwJVwiLCB3aWR0aDogXCIxMDAlXCIgfX1cclxuICAgICAgLz5cclxuICAgICAgPHNwYW5cclxuICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgcG9zaXRpb246IFwiYWJzb2x1dGVcIixcclxuICAgICAgICAgIHRvcDogXCIyMCVcIixcclxuICAgICAgICAgIGxlZnQ6IFwiMTAlXCIsXHJcbiAgICAgICAgICBmb250U2l6ZTogXCIycmVtXCIsXHJcbiAgICAgICAgfX1cclxuICAgICAgPlxyXG4gICAgICAgIHtwcm9kdWN0Py50aXRsZX1cclxuICAgICAgPC9zcGFuPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG4iXSwibmFtZXMiOlsiUmVhY3QiLCJ1c2VTdGF0ZSIsInVzZVJvdXRlciIsImR1bW15Y2FyZHMiLCJpZCIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJQcm9kdWN0Iiwicm91dGVyIiwiY29uc29sZSIsImxvZyIsInF1ZXJ5IiwicHJvZHVjdCIsInNldFByb2R1Y3QiLCJmaW5kIiwicCIsInBhcnNlSW50IiwiZGl2Iiwic3R5bGUiLCJ3aWR0aCIsImhlaWdodCIsInBvc2l0aW9uIiwiaW1nIiwic3JjIiwic3BhbiIsInRvcCIsImxlZnQiLCJmb250U2l6ZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/products/[id].jsx\n");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/products/[id].jsx"));
module.exports = __webpack_exports__;

})();